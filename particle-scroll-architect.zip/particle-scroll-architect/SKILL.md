---
name: particle-scroll-architect
description: Use when building, fixing, upgrading, or modifying 3D scroll-based particle experiences using React Three Fiber, GSAP, and custom shaders. This includes creating helical/DNA particle patterns, implementing scroll-driven state transitions, adding mouse interactions, morphing particles between GLB models, optimizing particle performance, and debugging shader code. Triggers on requests involving particles, shaders, R3F effects, scroll-based 3D animations, or three.quarks.
---

# Particle Scroll Architect

Expert guidance for building scroll-driven 3D particle experiences with React Three Fiber, GSAP, and custom shaders.

## When to Use This Skill

**Trigger conditions:**
- Creating new particle systems or effects
- Modifying existing particle animations
- Adding scroll-driven 3D experiences
- Implementing mouse interactions with particles
- Morphing particles between shapes or GLB models
- Debugging shader code (vertex/fragment)
- Optimizing particle performance
- Integrating GSAP ScrollTrigger with R3F

**Example triggers:**
- "Add a new particle state for the solutions section"
- "Make particles repel from the cursor"
- "Morph particles from sphere to logo shape"
- "Why are my particles flickering?"
- "What should we do with our particle animation?"

## Workflow Decision Tree

```
User Request
    │
    ├─► "Suggestions" / "What should we do?" / "Ideas for..."
    │       └─► Follow SUGGESTION WORKFLOW
    │
    ├─► "Create" / "Add" / "Implement" / "Build"
    │       └─► Follow GENERATION WORKFLOW
    │
    ├─► "Fix" / "Debug" / "Why is..." / "Not working"
    │       └─► Follow DEBUGGING WORKFLOW
    │
    └─► "Optimize" / "Performance" / "Slow"
            └─► Follow OPTIMIZATION WORKFLOW
```

## Suggestion Workflow

When asked for suggestions or recommendations:

1. **Analyze Current State**
   - Read existing particle component(s)
   - Identify current patterns (shader-based, drei, three.quarks)
   - Note scroll integration method (GSAP ScrollTrigger vs drei ScrollControls)

2. **Reference Expert Guide**
   - Load `references/particle-animation-expert.md`
   - Focus on sections relevant to current implementation

3. **Generate Recommendations**
   - Compare current implementation against reference patterns
   - Identify missing features from the checklist (Section 12)
   - Suggest improvements based on decision matrix (Section 1)
   - Propose new states, interactions, or effects

4. **Prioritize by Impact**
   - Visual impact vs. implementation effort
   - Performance implications
   - User experience improvements

## Generation Workflow

When asked to create or implement particle features:

1. **Load Reference**
   - Read `references/particle-animation-expert.md`
   - Focus on the specific section needed (e.g., Section 4 for GLB morphing)

2. **Follow Architecture Patterns**
   - Use the component structure from Section 2
   - Follow performance rules (useMemo for geometry, useRef for uniforms)
   - Match existing project patterns if modifying

3. **Implementation Checklist** (from Section 12)
   - [ ] Define particle states (one per scroll section)
   - [ ] Create BufferGeometry with custom attributes
   - [ ] Write vertex shader (position, animation, mouse)
   - [ ] Write fragment shader (color, alpha, shape)
   - [ ] Set up uniforms with useRef
   - [ ] Implement useFrame for continuous updates
   - [ ] Add GSAP ScrollTrigger for scroll sync
   - [ ] Create imperative handle for state transitions
   - [ ] Wire up ContentSections to trigger transitions
   - [ ] Add mouse interaction (repulsion/attraction)
   - [ ] Test performance
   - [ ] Clean up GSAP on unmount

4. **Validate Implementation**
   - Ensure no `useState` in animation loops
   - Confirm proper cleanup in useEffect returns
   - Verify shader uniforms match JS definitions

## Debugging Workflow

When fixing particle issues:

1. **Common Issues Reference**
   | Symptom | Likely Cause | Solution |
   |---------|--------------|----------|
   | Flickering | depthWrite: true | Set `depthWrite={false}` |
   | Disappearing | Z-fighting | Adjust camera near/far or depth settings |
   | No animation | Uniforms not updating | Check useFrame is updating uniforms |
   | Performance | Allocations in useFrame | Pre-allocate vectors, use useMemo |
   | Scroll not syncing | Missing ScrollTrigger cleanup | Add cleanup in useEffect return |

2. **Diagnostic Steps**
   - Check browser console for WebGL errors
   - Verify shader compiles (look for GLSL syntax errors)
   - Confirm uniforms are defined in both JS and GLSL
   - Test with reduced particle count

## Optimization Workflow

When improving performance:

1. **Load Section 11** of reference guide
2. **Apply optimizations in order:**
   - Pre-allocate vectors outside component
   - Use useMemo for geometry arrays
   - Implement frame skipping for heavy operations
   - Add LOD (Level of Detail) based on camera distance
   - Consider drei `<PerformanceMonitor>` for adaptive quality

## Quick Reference

**Decision Matrix:**
```
Need mathematical precision (helix, DNA)?  → Custom Shaders
Need fire/smoke/sparks quickly?            → three.quarks
Need particles on model surface?           → MeshSurfaceSampler + Shaders
Need shape-to-shape morphing?              → Multi-attribute shaders
Need simple ambient particles?             → drei <Sparkles>
Need scroll-driven scenes?                 → GSAP ScrollTrigger + useFrame
```

**Key Shader Settings:**
```jsx
<shaderMaterial
  transparent={true}
  depthWrite={false}
  depthTest={true}
  blending={THREE.AdditiveBlending}
/>
```

## Resources

### references/

- **particle-animation-expert.md** - Comprehensive 1300+ line guide covering:
  - Core technologies and decision matrices
  - React Three Fiber patterns and performance rules
  - Custom shader architecture (vertex/fragment templates)
  - GLB model particle morphing with MeshSurfaceSampler
  - Scroll-based animation integration (GSAP + drei)
  - useFrame patterns and priority system
  - Mouse interaction effects
  - State machine pattern for section transitions
  - drei helper components
  - three.quarks particle system integration
  - Performance optimization techniques
  - Complete implementation patterns and checklist

Load this reference when implementing any particle feature. For large codebases, use grep to find specific sections:
- `grep -n "Vertex Shader" references/particle-animation-expert.md`
- `grep -n "Mouse" references/particle-animation-expert.md`
- `grep -n "Performance" references/particle-animation-expert.md`
